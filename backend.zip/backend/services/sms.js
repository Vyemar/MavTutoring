import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";

const sns = new SNSClient({ region: process.env.AWS_REGION });

export const sendSMS = async ({ to, body }) => {
  if (!to) return;

  const params = {
    Message: body,
    PhoneNumber: to,                 // must be E.164 (+1…)
    MessageAttributes: {
/*
      "AWS.SNS.SMS.SenderID": {
        DataType: "String",
        StringValue: "MavAssist"
      },

      "AWS.SNS.SMS.OriginationNumber": {
        DataType: "String",
        StringValue: process.env.SNS_ORIGINATION_NUMBER
      },
      */
      "AWS.SNS.SMS.SMSType": {
        DataType: "String",
        StringValue: "Transactional"
      }
    }
  };

  try {
    const res = await sns.send(new PublishCommand(params));
    console.log(`SMS sent, MessageId: ${res.MessageId}`);
  } catch (err) {
    console.error("SMS failed:", err.name, err.message);
  }
};